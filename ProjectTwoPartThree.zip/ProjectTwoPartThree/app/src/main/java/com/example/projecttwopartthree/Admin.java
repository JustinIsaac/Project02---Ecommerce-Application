package com.example.projecttwopartthree;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.projecttwopartthree.DB.EcommerceDataBase;

@Entity(tableName = EcommerceDataBase.ADMIN_TABLE)
public class Admin {

    @PrimaryKey(autoGenerate = true)
    private int adminId;
    private String adminusername;
    private String adminpassword;

    public Admin(String adminusername, String adminpassword) {
        this.adminusername = adminusername;
        this.adminpassword = adminpassword;
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public String getAdminusername() {
        return adminusername;
    }

    public void setAdminusername(String adminusername) {
        this.adminusername = adminusername;
    }

    public String getAdminpassword() {
        return adminpassword;
    }

    public void setAdminpassword(String adminpassword) {
        this.adminpassword = adminpassword;
    }

}
