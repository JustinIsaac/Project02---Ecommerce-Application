package com.example.projecttwopartthree.DB;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.projecttwopartthree.Admin;
import com.example.projecttwopartthree.ECommerce;
import com.example.projecttwopartthree.Order;
import com.example.projecttwopartthree.Product;
import com.example.projecttwopartthree.User;

import java.util.List;

@Dao
public interface EcommerceDAO {

    @Insert
    void insert(ECommerce... eCommerces);

    @Update
    void update(ECommerce... eCommerces);

    @Delete
    void delete(ECommerce eCommerce);

    @Query("SELECT * FROM " + EcommerceDataBase.ECOMMERCE_TABLE + " WHERE ecommerceid = :ecommerceid")
    List<ECommerce> getEcommerceByEcommerceId(int ecommerceid);

    @Insert
    void insert(User... users);

    @Update
    void update(User... users);

    @Delete
    void delete(User users);

    @Query("SELECT * FROM " + EcommerceDataBase.USER_TABLE)
    List<User> getAllUsers();

    @Query("SELECT * FROM " + EcommerceDataBase.USER_TABLE + " WHERE username = :username")
    User getUserByUsername(String username);

    @Query("SELECT * FROM " + EcommerceDataBase.USER_TABLE + " WHERE userid = :userId")
    User getUserByUserID(int userId);

    @Insert
    void insert(Admin... admins);

    @Update
    void update(Admin... admins);

    @Delete
    void Delete(Admin... admins);


    @Query("SELECT * FROM " + EcommerceDataBase.ADMIN_TABLE)
    List<Admin> getAllAdmins();

    @Query("SELECT * FROM " + EcommerceDataBase.ADMIN_TABLE + " WHERE adminusername = :adminusername")
    Admin getAdminByUsername(String adminusername);

    @Query("SELECT * FROM " + EcommerceDataBase.ADMIN_TABLE + " WHERE adminid = :adminId")
    Admin getAdminByAdminID(int adminId);



    @Insert
    void insert(Product... products);

    @Update
    void update(Product... products);

    @Delete
    void Delete(Product... products);

    @Query("SELECT * FROM " + EcommerceDataBase.PRODUCT_TABLE)
    List<Product> getAllProducts();

    @Query("SELECT * FROM " + EcommerceDataBase.PRODUCT_TABLE + " WHERE productname = :productname")
    Product getProductByProductName(String productname);

    @Query("SELECT * FROM " + EcommerceDataBase.PRODUCT_TABLE + " WHERE productid = :productid")
    Product getProductByProductId(int productid);




    @Insert
    void insert(Order... orders);

    @Update
    void update(Order... orders);

    @Delete
    void Delete(Order... orders);

    @Query("SELECT * FROM " + EcommerceDataBase.ORDER_TABLE)
    List<Order> getAllOrders();

    @Query("SELECT * FROM " + EcommerceDataBase.ORDER_TABLE + " WHERE orderstatus = :orderstatus")
    Order getOrderByOrderStatus(String orderstatus);

    @Query("SELECT * FROM " + EcommerceDataBase.ORDER_TABLE + " WHERE orderid = :orderid")
    Order getOrderByOrderID(int orderid);


}
