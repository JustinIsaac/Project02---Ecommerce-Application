package com.example.projecttwopartthree;

import static com.example.projecttwopartthree.MainActivity.PREFERENCES_KEY;
import static com.example.projecttwopartthree.MainActivity.USER_ID_KEY;
import static com.example.projecttwopartthree.MainActivity.ADMIN_ID_KEY;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projecttwopartthree.DB.EcommerceDAO;
import com.example.projecttwopartthree.DB.EcommerceDataBase;

import java.util.List;

public class LoginActivity extends AppCompatActivity {


    private TextView usernameField;
    private TextView passwordField;
    private Button signin;
    private Button createaccount;
    private EcommerceDAO ecommerceDAO;

    private String username;
    private String password;
    private MenuItem settingsmenu;
    private MenuItem logoutmenu;
    private MenuItem usermenu;
    private MenuItem adminmenu;

    private User user;

    private Admin admin;

    SharedPreferences preferences = null;
    private int adminId = -1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        wireupDisplay();

        getDatabase();

        checkForUser();
        checkForAdmin();

    }

    private void checkForUser() {

        int userId = getIntent().getIntExtra(USER_ID_KEY, -1);

        if(userId != -1){
            return;
        }

//        if(preferences != null){
//            userId = preferences.getInt(USER_ID_KEY, -1);
//        }

        SharedPreferences preferences = getSharedPreferences(PREFERENCES_KEY, Context.MODE_PRIVATE);
//        if(preferences == null){
//            getPref();
//        }
        userId = preferences.getInt(USER_ID_KEY, -1);


        if(userId != -1){
            return;
        }

        List<User> users = ecommerceDAO.getAllUsers();

        if(users.size() <= 0){
            User defaultUser = new User("Justin", "j1234");
            User altUser = new User("testuser1", "testuser1");
            User admin = new User("admin2", "admin2");
            ecommerceDAO.insert(defaultUser,altUser,admin);
        }

        Intent intent = LoginActivity.intentFactory(this);
        startActivity(intent);

    }

//    private void checkForAdmin(){
//
//        adminId = getIntent().getIntExtra(ADMIN_ID_KEY,-1);
//
//        if(adminId!= -1){
//            return;
//        }
//
//        if(preferences == null){
//            getPref();
//        }
//        adminId = preferences.getInt(ADMIN_ID_KEY, -1);
//
//
//        if(adminId != -1){
//            return;
//        }
//
//        List<Admin> admins = ecommerceDAO.getAllAdmins();
//
//        if(admins.size() <= 0){
//            Admin admin1 = new Admin("admin2","admin2");
//            ecommerceDAO.insert(admin1);
//        }
//
//        Intent intent = LoginActivity.intentFactory(this);
//        startActivity(intent);
//    }

    void getPref() {
        preferences = this.getSharedPreferences(PREFERENCES_KEY, Context.MODE_PRIVATE);
    }

    private void checkForAdmin(){

        int adminId = getIntent().getIntExtra(ADMIN_ID_KEY,-1);

        if(adminId!= -1){
            return;
        }

        if(preferences == null){
            getPref();
        }
        adminId = preferences.getInt(ADMIN_ID_KEY, -1);


        if(adminId != -1){
            return;
        }

        List<Admin> admins = ecommerceDAO.getAllAdmins();

        if(admins.size() <= 0){
            Admin admin1 = new Admin("admin2","admin2");
            ecommerceDAO.insert(admin1);
        }

        Intent intent = LoginActivity.intentFactory(this);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_item,menu);
        MenuItem home=menu.add("Home");
        home.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        home.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(settingsmenu == findViewById(R.id.settings)){
            Toast.makeText(this, "You have clicked on Settings menu", Toast.LENGTH_LONG).show();
            return true;
        }
        else if (logoutmenu == findViewById(R.id.logout)) {
            Toast.makeText(this, "You have clicked on Logout menu", Toast.LENGTH_LONG).show();
            return true;
        }

        else if (usermenu == findViewById(R.id.userid)) {
            Toast.makeText(this, "User-1 is selected", Toast.LENGTH_LONG).show();
            //logoutUser();
            return true;
        }

        else if (adminmenu == findViewById(R.id.adminid)) {
            Toast.makeText(this, "Admin-1 is selected", Toast.LENGTH_LONG).show();
            return true;
        }
        else {
            return super.onOptionsItemSelected(item);
        }

    }


    private void wireupDisplay(){

        settingsmenu = findViewById(R.id.settings);
        logoutmenu = findViewById(R.id.logout);
        usermenu =  findViewById(R.id.userid);
        adminmenu = findViewById(R.id.adminid);


        usernameField = findViewById(R.id.UsernameEditText);
        passwordField = findViewById(R.id.PasswordEditText);
        signin = findViewById(R.id.SigninButton);
        createaccount = findViewById(R.id.CreateAccountButton);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getValuesFromDisplay();
                if(checkForUserInDatabase()){
                    if(!validateUserPassword()){
                        Toast.makeText(LoginActivity.this, "Invalid Password", Toast.LENGTH_LONG).show();
                    }
                    else{
                        //Toast.makeText(LoginActivity.this ,"Wegot here", Toast.LENGTH_LONG).show();
                        //startActivity(MainActivity.intentFactory(getApplicationContext(), user.getUserId()));
                        startActivity(MainActivity.intentFactory(getApplicationContext(), user.getUserId()));
                        //Intent intent = MainActivity.intentFactory(getApplicationContext(), user.getUserId());
                        //startActivity(intent);
                    }
                }
            }
        });



        createaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getValuesFromDisplay();
                if(checkForUserInDatabase()){
                    if(!validateUserPassword()){
                        Toast.makeText(LoginActivity.this, "Invalid Password", Toast.LENGTH_LONG).show();
                    }
                    else{
                        //Toast.makeText(LoginActivity.this ,"Wegot here", Toast.LENGTH_LONG).show();
                        startActivity(MainActivity.intentFactory(getApplicationContext(), user.getUserId()));
                        Toast.makeText(getApplicationContext(),"Account Created",Toast.LENGTH_LONG).show();
                        //Intent intent = MainActivity.intentFactory(getApplicationContext(), user.getUserId());
                        //startActivity(intent);
                    }
                }
            }
        });

//        createaccount.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getValuesFromDisplay();
//                if(checkForAdminInDatabase()){
//                    if(!validateAdminPassword()){
//                        Toast.makeText(LoginActivity.this, "Invalid Password", Toast.LENGTH_LONG).show();
//                    }
//                    else{
//                        //Toast.makeText(LoginActivity.this ,"Wegot here", Toast.LENGTH_LONG).show();
//                        startActivity(MainActivity.intentFactory(getApplicationContext(), admin.getAdminId()));
//                        Toast.makeText(getApplicationContext(),"Account Created",Toast.LENGTH_LONG).show();
//                        //Intent intent = MainActivity.intentFactory(getApplicationContext(), user.getUserId());
//                        //startActivity(intent);
//                    }
//                }
//            }
//        });


        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getValuesFromDisplay();
                if(checkForAdminInDatabase()){
                    if(!validateAdminPassword()){
                        Toast.makeText(LoginActivity.this, "Invalid Password", Toast.LENGTH_LONG).show();
                    }
                    else{
                        //Toast.makeText(LoginActivity.this ,"Wegot here", Toast.LENGTH_LONG).show();
                        //startActivity(MainActivity.intentFactory(getApplicationContext(), user.getUserId()));
                        startActivity(MainActivity.intentFactory(getApplicationContext(),admin.getAdminId()));
                        //Intent intent = MainActivity.intentFactory(getApplicationContext(), user.getUserId());
                        //startActivity(intent);
                    }
                }
            }
        });


    }

    private boolean validateUserPassword(){
        return user.getPassword().equals(password);
    }

    private boolean validateAdminPassword() {
        return admin.getAdminpassword().equals(password);
    }

    private void getValuesFromDisplay(){
        username = usernameField.getText().toString();
        password = passwordField.getText().toString();
    }

    private boolean checkForUserInDatabase(){
        user = ecommerceDAO.getUserByUsername(username);
        if(user == null){
            Toast.makeText(this, "no user" + username + "found",Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private boolean checkForAdminInDatabase(){
        admin = ecommerceDAO.getAdminByUsername(username);
        if(admin == null){
            Toast.makeText(this, "no admin" + username + "found",Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void getDatabase(){

        ecommerceDAO = EcommerceDataBase.getInstance(getApplicationContext()).ecommerceDAO();

//        ecommerceDAO = Room.databaseBuilder(this, EcommerceDataBase.class, EcommerceDataBase.DATABASE_NAME)
//                .allowMainThreadQueries()
//                .build()
//                .ecommerceDAO();
    }

    public static Intent intentFactory(Context context){
        Intent intent = new Intent(context, LoginActivity.class);
        return intent;
    }
}