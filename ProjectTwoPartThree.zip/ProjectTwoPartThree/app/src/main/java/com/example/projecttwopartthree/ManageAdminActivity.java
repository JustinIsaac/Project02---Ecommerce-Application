package com.example.projecttwopartthree;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ManageAdminActivity extends AppCompatActivity {

    private Button b1;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_manage);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        b1 = findViewById(R.id.nextbutton);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(ManageAdminActivity.this, "Products View", Toast.LENGTH_LONG).show();
                startActivity(ProductsManageAdminActivity.intentFactory(getApplicationContext()));
            }
        });

    }

    public static Intent intentFactory(Context context){
        Intent intent = new Intent(context, ManageAdminActivity.class);
        return intent;
    }
}