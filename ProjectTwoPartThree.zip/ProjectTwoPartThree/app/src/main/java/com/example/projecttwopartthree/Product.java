package com.example.projecttwopartthree;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.projecttwopartthree.DB.EcommerceDataBase;

@Entity(tableName = EcommerceDataBase.PRODUCT_TABLE)
public class Product {

    @PrimaryKey(autoGenerate = true)
    private int productId;
    private String productname;
    private String productquantity;
    private String productprice;

    public Product(int productId, String productname, String productquantity, String productprice) {
        this.productId = productId;
        this.productname = productname;
        this.productquantity = productquantity;
        this.productprice = productprice;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getProductquantity() {
        return productquantity;
    }

    public void setProductquantity(String productquantity) {
        this.productquantity = productquantity;
    }

    public String getProductprice() {
        return productprice;
    }

    public void setProductprice(String productprice) {
        this.productprice = productprice;
    }
}
