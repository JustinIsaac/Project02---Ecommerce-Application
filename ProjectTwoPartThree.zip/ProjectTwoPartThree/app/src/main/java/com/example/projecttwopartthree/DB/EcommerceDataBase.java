package com.example.projecttwopartthree.DB;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.projecttwopartthree.Admin;
import com.example.projecttwopartthree.ECommerce;
import com.example.projecttwopartthree.Order;
import com.example.projecttwopartthree.Product;
import com.example.projecttwopartthree.User;

@Database(entities = {ECommerce.class , User.class , Admin.class , Product.class , Order.class}, version = 3)
public abstract class EcommerceDataBase extends RoomDatabase {

    public static final String DATABASE_NAME = "Ecommerce.db";
    public static final String ECOMMERCE_TABLE = "Ecommerce_table";
    public static final String USER_TABLE = "USER_TABLE";
    public static final String ADMIN_TABLE = "ADMIN_TABLE";
    public static final String PRODUCT_TABLE = "PRODUCT_TABLE";
    public static final String ORDER_TABLE = "ORDER_TABLE";
    private static volatile EcommerceDataBase dataBaseinstance;
    private static final Object LOCK = new Object();

    public abstract EcommerceDAO ecommerceDAO();

    public static EcommerceDataBase getInstance(Context context){
        if(dataBaseinstance == null){
            synchronized (LOCK){
                if (dataBaseinstance == null){
                    dataBaseinstance = Room.databaseBuilder(context.getApplicationContext(),EcommerceDataBase.class,DATABASE_NAME)
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return dataBaseinstance;
    }

}

