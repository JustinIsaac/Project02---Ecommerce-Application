package com.example.projecttwopartthree;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.projecttwopartthree.DB.EcommerceDataBase;

@Entity(tableName = EcommerceDataBase.ECOMMERCE_TABLE)
public class ECommerce {

    @PrimaryKey(autoGenerate = true)
    private int ecommerceId;
    private String username;
    private String password;


    public ECommerce(String username, String password , int ecommerceId) {
        this.username = username;
        this.password = password;
        this.ecommerceId = ecommerceId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "LandingPage{" +
                "EcommerceID='" + ecommerceId + '\'' +
                "Username='" + username + '\'' +
                ", Password='" + password + '\'' +
                '}';
    }

    public int getEcommerceId() {
        return ecommerceId;
    }

    public void setEcommerceId(int ecommerceId) {
        this.ecommerceId = ecommerceId;
    }
}
