package com.example.projecttwopartthree;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.projecttwopartthree.DB.EcommerceDataBase;

import java.util.Date;

@Entity(tableName = EcommerceDataBase.ORDER_TABLE)
public class Order {

    @PrimaryKey(autoGenerate = true)
    private int orderId;
    private String orderstatus;
    private String orderdate;
    private int totalitems;

    public Order(int orderId, String orderstatus, String orderdate, int totalitems) {
        this.orderId = orderId;
        this.orderstatus = orderstatus;
        this.orderdate = orderdate;
        this.totalitems = totalitems;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getOrderstatus() {
        return orderstatus;
    }

    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }

    public String getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(String orderdate) {
        this.orderdate = orderdate;
    }

    public int getTotalitems() {
        return totalitems;
    }

    public void setTotalitems(int totalitems) {
        this.totalitems = totalitems;
    }
}
