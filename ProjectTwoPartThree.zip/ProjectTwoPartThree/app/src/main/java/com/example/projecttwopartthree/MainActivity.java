package com.example.projecttwopartthree;

import static android.app.PendingIntent.getActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.projecttwopartthree.DB.EcommerceDAO;
import com.example.projecttwopartthree.DB.EcommerceDataBase;
import com.google.android.material.appbar.AppBarLayout;

import java.util.List;

public class MainActivity extends AppCompatActivity {


    protected static final String USER_ID_KEY = "com.example.projecttwopartthree.userIdKey";
    protected static final String PREFERENCES_KEY = "com.example.projecttwopartthree.PREFERENCE_KEY";
    protected static final String ADMIN_ID_KEY = "com.example.projecttwopartthree.adminidkey";

    //ActivityMainBinding binding;

    //ActivityMainBinding binding;

    private TextView message;
    private EditText ProductDescription;
    private EditText Electronics;

    private Button search;
    private Button reset;
    private EcommerceDAO ecommerceDAO;
    private ECommerce eCommerces;

    private List<ECommerce> eCommerceList;

    private int userId = -1;
    private int adminId = -1;

    SharedPreferences preferences = null;
    private User user;
    private Admin admin;
    private Menu optionsMenu;

    private TextView top;
    private Button confirmbutton;
    private TextView bottom;

    private TextView atv;
    private Button ab;

    private MenuItem settingsmenu;
    private MenuItem logoutmenu;
    private MenuItem usermenu;
    private MenuItem adminmenu;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getDatabase();

        checkForUser();

        checkForAdmin();

        addUserToPreference(userId);

        logInUser(userId);
        logInAdmin(adminId);


        ProductDescription = findViewById(R.id.AdminProductDescriptionEditText);
        Electronics = findViewById(R.id.AdminElectronicsEditText);
        search = findViewById(R.id.sb);
        reset = findViewById(R.id.ResetButton);
        message = findViewById(R.id.AdminTextViewMessage);

        atv = findViewById(R.id.AdmintextView);
        ab = findViewById(R.id.adminsecretbutton);


        top = findViewById(R.id.AdminMainTextView);
        confirmbutton = findViewById(R.id.ButtonC);
        bottom = findViewById(R.id.DialogueTextViewMessage);

        settingsmenu = findViewById(R.id.settings);
        logoutmenu = findViewById(R.id.logout);
        usermenu =  findViewById(R.id.userid);
        adminmenu = findViewById(R.id.adminid);


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String productcontext = ProductDescription.getText().toString();
                String typeofproduct = Electronics.getText().toString();

                String display = "Product Description : " + productcontext + "\n" +
                                 "Product Type : " + typeofproduct + "\n";

                Toast.makeText(getApplicationContext(), display , Toast.LENGTH_LONG).show();
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProductDescription.setText(" ");
                Electronics.setText(" ");
            }
        });

        confirmbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomDialogue();
            }
        });


        //refreshDisplay();

        if(admin != null && admin.getAdminusername().equals("admin2")){
            atv.setVisibility(View.VISIBLE);
            ab.setVisibility(View.VISIBLE);
        }
        else {
            atv.setVisibility(View.INVISIBLE);
            ab.setVisibility(View.INVISIBLE);
        }

        ab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Admin View", Toast.LENGTH_LONG).show();
                        startActivity(ManageAdminActivity.intentFactory(getApplicationContext()));
                    }
        });
    }

    void showCustomDialogue(){
        final Dialog dialog= new Dialog(MainActivity.this);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.custom_dialogue);
        final CheckBox productone = dialog.findViewById(R.id.checkBox1);
        final CheckBox producttwo = dialog.findViewById(R.id.checkBox2);
        final CheckBox productthree = dialog.findViewById(R.id.checkBox3);
        final CheckBox productfour = dialog.findViewById(R.id.checkBox4);
        Button Purchase = dialog.findViewById(R.id.order);


        Purchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean hasAccepted1 = productone.isChecked();
                Boolean hasAccepted2 = producttwo.isChecked();
                Boolean hasAccepted3 = productthree.isChecked();
                Boolean hasAccepted4 = productfour.isChecked();
                populateTextView(hasAccepted1,hasAccepted2, hasAccepted3,hasAccepted4);
                dialog.dismiss();

                int price = 0;
                StringBuilder result = new StringBuilder();
                result.append("Items Selected :- ");
                if(productone.isChecked()){
                    result.append("\nMobile ");
                    price += 500;
                }
                if(producttwo.isChecked()){
                    result.append("\nLaptop ");
                    price += 2000;
                }
                if(productthree.isChecked()){
                    result.append("\nWatch ");
                    price += 100;
                }
                if(productfour.isChecked()){
                    result.append("\nTelevision ");
                    price += 400;
                }
                result.append("\n" + "Total :- " + price + "$");
                //Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();
                bottom.setText(result.toString());
            }
        });
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.WRAP_CONTENT);
    }

    @SuppressLint("StringFormatInvalid")
    void populateTextView(Boolean hasAccepted1, Boolean hasAccepted2, Boolean hasAccepted3, Boolean hasAccepted4){
        bottom.setVisibility(View.VISIBLE);
        String selected = "True";
        if(!hasAccepted1 && !hasAccepted2 && !hasAccepted3 && !hasAccepted4){
            selected = "False";
        }
        //bottom.setText(String.format(getString(R.string.info),hasAccepted1,hasAccepted2,hasAccepted3,hasAccepted4,selected));

    }

    private void logInUser(int userId) {
        user = ecommerceDAO.getUserByUserID(userId);
        addUserToPreference(userId);
        invalidateOptionsMenu();
    }

    private void logInAdmin(int adminId){
        admin = ecommerceDAO.getAdminByAdminID(adminId);
        addAdminToPreference(adminId);
        invalidateOptionsMenu();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if(user != null){
            MenuItem item = menu.findItem(R.id.userid);
            if(item!= null){
                item.setTitle(user.getUsername());
            }
            else {

            }
        }
        return super.onPrepareOptionsMenu(menu);
    }

    private void addUserToPreference(int userId) {
        if(preferences == null){
            getPref();
        }
        SharedPreferences.Editor  editor = preferences.edit();
        editor.putInt(USER_ID_KEY, userId);
        editor.apply();
    }

    private void addAdminToPreference(int adminId){
        if(preferences == null){
            getPref();
        }
        SharedPreferences.Editor  editor = preferences.edit();
        editor.putInt(ADMIN_ID_KEY, adminId);
        editor.apply();
    }


    private void getDatabase() {

        ecommerceDAO = EcommerceDataBase.getInstance(getApplicationContext()).ecommerceDAO();

//        ecommerceDAO = Room.databaseBuilder(this, EcommerceDataBase.class, EcommerceDataBase.DATABASE_NAME)
//                .allowMainThreadQueries()
//                .build()
//                .ecommerceDAO();
    }

    protected void checkForUser() {
        userId = getIntent().getIntExtra(USER_ID_KEY, -1);

        if(userId != -1){
            return;
        }

//        if(preferences != null){
//            userId = preferences.getInt(USER_ID_KEY, -1);
//        }

        if(preferences == null){
            getPref();
        }
        userId = preferences.getInt(USER_ID_KEY, -1);


        if(userId != -1){
            return;
        }

        List<User> users = ecommerceDAO.getAllUsers();

        if(users.size() <= 0){
            User defaultUser = new User("Justin", "j1234");
            User altUser = new User("testuser1", "testuser1");
            ecommerceDAO.insert(defaultUser,altUser);
        }

        Intent intent = LoginActivity.intentFactory(this);
        startActivity(intent);

    }

    protected void checkForAdmin(){

        adminId = getIntent().getIntExtra(ADMIN_ID_KEY,-1);

        if(adminId!= -1){
            return;
        }

        if(preferences == null){
            getPref();
        }
        adminId = preferences.getInt(ADMIN_ID_KEY, -1);


        if(adminId != -1){
            return;
        }

        List<Admin> admins = ecommerceDAO.getAllAdmins();

        if(admins.size() <= 0){
            Admin admin1 = new Admin("admin2","admin2");
            ecommerceDAO.insert(admin1);
        }

        Intent intent = LoginActivity.intentFactory(this);
        startActivity(intent);
    }

    void getPref() {
        preferences = this.getSharedPreferences(PREFERENCES_KEY, Context.MODE_PRIVATE);
    }

    private void logoutUser(){
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        alertBuilder.setMessage("Logout?");

        alertBuilder.setPositiveButton(getString(R.string.yes),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        clearUserFromIntent();
                        clearUserFromPref();
                        userId = -1;
                        checkForUser();
                    }
                });
        alertBuilder.setNegativeButton(getString(R.string.no),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this, "You're Logged Out",Toast.LENGTH_LONG).show();

                    }
                });
        alertBuilder.create().show();
    }

    private void logoutAdmin(){
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        alertBuilder.setMessage("Logout?");

        alertBuilder.setPositiveButton(getString(R.string.yes),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        clearUserFromIntent();
                        clearUserFromPref();
                        adminId = -1;
                        checkForAdmin();
                    }
                });
        alertBuilder.setNegativeButton(getString(R.string.no),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this, "You're Logged Out",Toast.LENGTH_LONG).show();

                    }
                });
        alertBuilder.create().show();
    }

    private void clearUserFromIntent() {
        getIntent().putExtra(USER_ID_KEY, -1);
    }

    private void clearUserFromPref() {
        addUserToPreference(-1);
    }

    private void clearAdminFromIntent(){
        getIntent().putExtra(ADMIN_ID_KEY, -1);
    }

    private void clearAdminFromPref() {
        addAdminToPreference(-1);
    }

//    private void refreshDisplay(){
//        eCommerceList = (List<ECommerce>) ecommerceDAO.getUserByUserID(userId);
//
//        if(!eCommerceList.isEmpty()){
//            StringBuilder stringBuilder = new StringBuilder();
//            for(ECommerce eCommerce: eCommerceList){
//                stringBuilder.append(eCommerce.toString());
//            }
//            message.setText(stringBuilder.toString());
//        }else {
//            message.setText(R.string.no_login_message);
//        }
//    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuItem item=menu.add("Home"); //your desired title here
//        //item.setIcon(R.drawable.baseline_home_24); //your desired icon here
//        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
//        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
//            @Override
//            public boolean onMenuItemClick(MenuItem item) {
//                return false;
//            }
//        });
//        return super.onCreateOptionsMenu(menu);
//    }


    //Original One
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.menu_item,menu);
//        MenuItem home=menu.add("Home");
//        home.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
//        home.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
//            @Override
//            public boolean onMenuItemClick(MenuItem item) {
//                return true;
//            }
//        });
//        return super.onCreateOptionsMenu(menu);
//    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater menuInflater = getMenuInflater();
//        menuInflater.inflate(R.menu.menu_item,menu);
////        return super.onCreateOptionsMenu(menu);
//        return true;
//    }

    //original two

//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//
//        if (settingsmenu == findViewById(R.id.settings)) {
//            Toast.makeText(this, "You have clicked on Settings menu", Toast.LENGTH_LONG).show();
//            return true;
//        } else if (logoutmenu == findViewById(R.id.logout)) {
//            Toast.makeText(this, "You have clicked on Logout menu", Toast.LENGTH_LONG).show();
//            return true;
//        } else if (usermenu == findViewById(R.id.userid)) {
//            Toast.makeText(this, "User-1 is selected", Toast.LENGTH_LONG).show();
//            logoutUser();
//            return true;
//        } else if (adminmenu == findViewById(R.id.adminid)) {
//            Toast.makeText(this, "Admin-1 is selected", Toast.LENGTH_LONG).show();
//            return true;
//        } else {
//            return super.onOptionsItemSelected(item);
//        }
//    }


//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//
//        String settings = String.valueOf(R.id.settings);
//        String logout = String.valueOf(R.id.logout);
//        String userid = String.valueOf(R.id.userid);
//        String adminid = String.valueOf(R.id.adminid);
//
//        if (settings == String.valueOf(R.id.settings)) {
//            Toast.makeText(this, "You have clicked on Settings menu", Toast.LENGTH_LONG).show();
//            return true;
//        }
//
//        else if (logout == String.valueOf(R.id.logout)) {
//            Toast.makeText(this, "You have clicked on Logout menu", Toast.LENGTH_LONG).show();
//            return true;
//        }
//
//        else if (userid == String.valueOf(R.id.userid)) {
//            Toast.makeText(this, "User-1 is selected", Toast.LENGTH_LONG).show();
//            logoutUser();
//            return true;
//        }
//
//        else if (adminid == String.valueOf(R.id.adminid)) {
//            Toast.makeText(this, "Admin-1 is selected", Toast.LENGTH_LONG).show();
//            return true;
//        }
//        else {
//            return super.onOptionsItemSelected(item);
//        }
//    }

//        switch (item.getItemId()){
//
//            case settings:
//                Toast.makeText(this,"You have clicked on Settings menu" ,Toast.LENGTH_LONG).show();
//                return true;
//            case R.id.logout:
//                Toast.makeText(this, "You have clicked on Logout menu" ,Toast.LENGTH_LONG).show();
//                return true;
//            case R.id.userid:
//                Toast.makeText(this,"User-1 is selected" , Toast.LENGTH_LONG).show();
//                logoutUser();
//                return true;
//            case R.id.adminid:
//                Toast.makeText(this,"Admin-1 is selected" , Toast.LENGTH_LONG).show();
//            default:
//                return super.onOptionsItemSelected(item);
//        }

//    }

//    public static Intent intentFactory(Context context, int adminId){
//        Intent intent = new Intent(context, MainActivity.class);
//        //intent.putExtra(USER_ID_KEY, userId);
//        intent.putExtra(ADMIN_ID_KEY, adminId);
//        return intent;
//    }

    public static Intent intentFactory(Context context, int userId){
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra(USER_ID_KEY,userId);
        return intent;
    }

//    public static Intent intentFactory(Context context, int adminId){
//        Intent intent = new Intent(context, MainActivity.class);
//        intent.putExtra(ADMIN_ID_KEY,adminId);
//        return intent;
//    }

}
