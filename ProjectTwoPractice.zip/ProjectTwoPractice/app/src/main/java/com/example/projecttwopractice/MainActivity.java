package com.example.projecttwopractice;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuItemImpl;
import androidx.room.Room;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projecttwopractice.DB.EcommerceDAO;
import com.example.projecttwopractice.DB.EcommerceDataBase;
import com.example.projecttwopractice.databinding.ActivityMainBinding;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String USER_ID_KEY = "com.example.projecttwopractic.userIdKey";
    private static final String PREFERENCES_KEY = "com.example.projecttwopractic.PREFERENCE_KEY";
    ActivityMainBinding binding;

    private TextView message;
    private EditText ProductDescription;
    private EditText Electronics;

    private Button search;
    private Button reset;
    private TextView admintv;

    private EcommerceDAO ecommerceDAO;
    private ECommerce eCommerces;

    private List<ECommerce> eCommerceList;

    private int userId = -1;

    private SharedPreferences preferences = null;
    private User user;
    private User admin;
    private Menu optionsMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDatabase();
        
        checkForUser();

        addUserToPreference(userId);

        logInUser(userId);

//        binding = ActivityMainBinding.inflate(getLayoutInflater());
//        setContentView(binding.getRoot());
//
//        username = binding.UsernameEditText;
//        password = binding.PasswordEditText;
//        signin = binding.SigninButton;
//        createaccount = binding.CreateAccountButton;
//        message = binding.TextViewMessage;

        ProductDescription = findViewById(R.id.ProductDescriptionEditText);
        Electronics = findViewById(R.id.ElectronicsEditText);
        search = findViewById(R.id.SearchButton);
        reset = findViewById(R.id.ResetButton);
        message = findViewById(R.id.TextViewMessage);

        refreshDisplay();

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ECommerce e = getValuesFromDisplay();
//                ecommerceDAO.insert(e);
//                refreshDisplay();
            }
        });

        if(user != null && user.getUsername().equals("admin2")){
            admintv.setVisibility(View.VISIBLE);
        } else {
            admintv.setVisibility(View.INVISIBLE);
        }

    }

    private void logInUser(int userId) {
        user = ecommerceDAO.getUserByUserID(userId);
        addUserToPreference(userId);
        invalidateOptionsMenu();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if(user != null){
            MenuItem item = menu.findItem(R.id.userMenuLogout);
            item.setTitle(user.getUsername());
        }
        return super.onPrepareOptionsMenu(menu);
    }

    private void addUserToPreference(int userId) {
        if(preferences == null){
            getPref();
        }
        SharedPreferences.Editor  editor = preferences.edit();
        editor.putInt(USER_ID_KEY, userId);
        editor.apply();
    }

    private void getDatabase() {

        ecommerceDAO = Room.databaseBuilder(this, EcommerceDataBase.class, EcommerceDataBase.DATABASE_NAME)
                .allowMainThreadQueries()
                .build()
                .ecommerceDAO();
    }

    private void checkForUser() {
        userId = getIntent().getIntExtra(USER_ID_KEY, -1);

        if(userId != -1){
            return;
        }

//        if(preferences != null){
//            userId = preferences.getInt(USER_ID_KEY, -1);
//        }

        if(preferences == null){
            getPref();
        }
        userId = preferences.getInt(USER_ID_KEY, -1);


        if(userId != -1){
            return;
        }

        List<User> users = ecommerceDAO.getAllUsers();

        if(users.size() <= 0){
            User defaultUser = new User("Justin", "j1234");
            User altUser = new User("testuser1", "testuser1");
            User admin = new User("admin2", "admin2");
            ecommerceDAO.insert(defaultUser,altUser,admin);
        }

        Intent intent = LoginActivity.intentFactory(this);
        startActivity(intent);

    }

    private void getPref() {
        preferences = this.getSharedPreferences(PREFERENCES_KEY, Context.MODE_PRIVATE);
    }

    private void logotUser(){
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        alertBuilder.setMessage("Logout?");

        alertBuilder.setPositiveButton(getString(R.string.yes),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        clearUserFromIntent();
                        clearUserFromPref();
                        userId = -1;
                        checkForUser();
                    }
                });
        alertBuilder.setNegativeButton(getString(R.string.no),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this, "You're Logged Out",Toast.LENGTH_LONG).show();

                    }
                });
        alertBuilder.create().show();
    }

    private void clearUserFromIntent() {
        getIntent().putExtra(USER_ID_KEY, -1);
    }

    private void clearUserFromPref() {
        addUserToPreference(-1);
    }

    private void refreshDisplay(){
        eCommerceList = (List<ECommerce>) ecommerceDAO.getUserByUserID(userId);
        
        if(!eCommerceList.isEmpty()){
            StringBuilder stringBuilder = new StringBuilder();
            for(ECommerce eCommerce: eCommerceList){
                stringBuilder.append(eCommerce.toString());
            }
            message.setText(stringBuilder.toString());
        }else {
            message.setText(R.string.no_login_message);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return true;
    }

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()){
//            case R.id.userid:
//                Toast.makeText(this,"User-1 is selected" , Toast.LENGTH_LONG).show();
//                return true;
//            case R.id.adminid:
//                Toast.makeText(this,"Admin-1 is selected" , Toast.LENGTH_LONG).show();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.userid:
                logotUser();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public static Intent intentFactory(Context context, int userId){
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra(USER_ID_KEY, userId);
        return intent;
    }
}