package com.example.projecttwopractice.DB;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.projecttwopractice.ECommerce;
import com.example.projecttwopractice.User;

@Database(entities = {ECommerce.class , User.class}, version = 2)
public abstract class EcommerceDataBase extends RoomDatabase {

    public static final String DATABASE_NAME = "Ecommerce.db";
    public static final String ECOMMERCE_TABLE = "Ecommerce_table";
    public static final String USER_TABLE = "USER_TABLE";

    private static volatile EcommerceDataBase dataBaseinstance;
    private static final Object LOCK = new Object();

    public abstract EcommerceDAO ecommerceDAO();

    public static EcommerceDataBase getInstance(Context context){
        if(dataBaseinstance == null){
            synchronized (LOCK){
                if (dataBaseinstance == null){
                    dataBaseinstance = Room.databaseBuilder(context.getApplicationContext(),EcommerceDataBase.class,DATABASE_NAME).build();
                }
            }
        }
        return dataBaseinstance;
    }

}

