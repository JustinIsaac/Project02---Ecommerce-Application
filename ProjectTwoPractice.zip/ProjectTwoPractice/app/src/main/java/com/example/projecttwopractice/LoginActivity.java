package com.example.projecttwopractice;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projecttwopractice.DB.EcommerceDAO;
import com.example.projecttwopractice.DB.EcommerceDataBase;

public class LoginActivity extends AppCompatActivity {

    private TextView usernameField;
    private TextView passwordField;
    private Button signin;
    private Button createaccount;
    private EcommerceDAO ecommerceDAO;

    private String username;
    private String password;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        wireupDisplay();

        getDatabase();

    }

    private void wireupDisplay(){
        usernameField = findViewById(R.id.UsernameEditText);
        passwordField = findViewById(R.id.PasswordEditText);
        signin = findViewById(R.id.SigninButton);
        createaccount = findViewById(R.id.CreateAccountButton);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getValuesFromDisplay();
                if(checkForUserInDatabase()){
                    if(!validatePassword()){
                        Toast.makeText(LoginActivity.this, "Invalid Password", Toast.LENGTH_LONG).show();
                    }
                    else{
                        Intent intent = MainActivity.intentFactory(getApplicationContext(),user.getUserId());
                        startActivity(intent);
                    }
                }
            }
        });

    }

    private boolean validatePassword(){
        return user.getPassword().equals(password);
    }

    private void getValuesFromDisplay(){
        username = usernameField.getText().toString();
        password = passwordField.getText().toString();
    }

    private boolean checkForUserInDatabase(){
        user = ecommerceDAO.getUserByUsername(username);
        if(user == null){
            Toast.makeText(this, "no user" + username + "found",Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void getDatabase(){

        ecommerceDAO = Room.databaseBuilder(this, EcommerceDataBase.class, EcommerceDataBase.DATABASE_NAME)
                .allowMainThreadQueries()
                .build()
                .ecommerceDAO();
    }

    public static Intent intentFactory(Context context){
        Intent intent = new Intent(context, LoginActivity.class);
        return intent;
    }
}