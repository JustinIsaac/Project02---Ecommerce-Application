package com.example.projecttwopractice;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.projecttwopractice.DB.EcommerceDataBase;

@Entity(tableName = EcommerceDataBase.ECOMMERCE_TABLE)
public class ECommerce {

    @PrimaryKey(autoGenerate = true)
    private int EcommerceId;
    private String Username;
    private String Password;


    public ECommerce(String username, String password , int ecommerceId) {
        Username = username;
        Password = password;
        EcommerceId = ecommerceId;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    @Override
    public String toString() {
        return "LandingPage{" +
                "EcommerceID='" + EcommerceId + '\'' +
                "Username='" + Username + '\'' +
                ", Password='" + Password + '\'' +
                '}';
    }

    public int getEcommerceId() {
        return EcommerceId;
    }

    public void setEcommerceId(int ecommerceId) {
        this.EcommerceId = ecommerceId;
    }
}
